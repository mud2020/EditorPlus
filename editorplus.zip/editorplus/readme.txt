=== EditorPlus ===
Contributors: munirkamal
Tags: Gutenberg blocks, WordPress blocks, gutenberg, blocks, Gutenberg editor
Requires at least: 5.0
Tested up to: 5.4
Requires PHP: 5.6
Stable tag: 1.1.0
License: GPL-3.0
License URI: http://www.gnu.org/licenses/gpl-3.0.html

EditorsPlus extends Gutenberg editor with advanced design controls and more features.


== Description ==

= Gutenberg Page Builder Toolkit - EditorPlus =

https://www.youtube.com/watch?v=sU0LkhS8OMk

[EditorPlus](https://wpeditorplus.com?utm_medium=wp.org&utm_source=wordpressorg&utm_campaign=readme&utm_content=editorplus) extends Gutenberg editor with advanced design controls and more features.

**You can design better pages in Gutenberg editor, faster.**

## NoCode Styling Editor for WordPress

Supercharge Gutenberg Editor with following styling controls.


📐 Spacing

🖼 Border

🏞 Background

❑  Box-Shadow

👀 Visibility 

🔜 More features to be added.


⭐️ All these stylings can be adjusted for Responsive (Desktop, Tablet & mobile) and Hover!

## Custom CSS Editor for Power Users

You can write your custom CSS code as well. The custom CSS code box will be available for all Gutenberg core blocks as well as via the plugin admin area for writing global CSS that applies throughout your website (including Gutenberg editor screen).


## There is more to come, stay tuned.

More exciting features and enhancements are planned for the WordPress Gutenberg Editor. Stay tuned for updates. 😇



== Installation ==
1. Upload the entire plugin folder to the `/wp-content/plugins/` directory.
1. Activate the plugin through the \'Plugins\' menu in WordPress.

Once Activated, you will see new styling options for all core Blocks in the Gutenberg editor.

Make sure to check out the Admin are of the plugin for configuration settings.

== Screenshots ==
1. Background (Solid, Gradient, Image)
2. Box-Shadow
3. Border & Border Radius
4. Spacing (Margin & Padding)

== Changelog ==

=1.1.0
* Added: Custom CSS Editor
* Added: Overflow property under extra panel
* Added: z-index property under extra panel
* Bug Fixes

= 1.0.0 =
* Initial release